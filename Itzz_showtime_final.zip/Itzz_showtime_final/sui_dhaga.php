<?php 
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Sui Dhaga</title>
	<link rel="stylesheet" type="text/css" href="ticket_booking_button.css">
	<link rel="shortcut icon" href="clapboard.png">

<style type="text/css">

		a.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 10px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}
	
		video
		{
			text-align:center;
			margin:0 auto;
			display:block;
			object-fit: inherit;
		
    		max-height: 400px;
    		min-width: 100%;
   			object-fit: fill;
		}

		#rcorners
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 2px solid #909497;
    		padding: 20px; 
    		width: 50px;
    		height: 10px; 
    		text-align:center;   
		}

</style>

<style>
	
	*{
		margin: 0;
		padding:0;
		font-family: verdana;
	}
#main{
	width: 100%;
	height:15vh;
}
nav{
	z-index:1;
	width: 100%;
	height: 80px;
	background-color: #000;
	line-height: 80px;
	position: fixed;
	top: 0;
}
nav ul{
	float: right;
	margin-right: 30px;
}
nav ul li{
	list-style-type: none;
	display: inline-block;
	transition: 0.8s all;
}

nav ul li:hover{
	background-color: #f39d1a;
}
nav ul li a{
	text-decoration: none;
	color: #fff;
	padding: 30px

}

#synopsis
{
	font-size: 20px;
	font-weight: 700;
}
#round
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 4px solid #909497;
    		padding: 20px 20px 22px 20px; 
    		width: 6px;
    		height: 6px; 

    		   
		}

</style>
</head>
<body>
	<div id="main">
		<nav>
		<img src="itzz_showtime_final.jpg" width="100" height="80">
			<ul>
				
				<?php  if (isset($_SESSION['username'])) : ?>
					
					<li style="color: white;"><img src="login_icon.jpg" width="30" height="30">Hi,<?php echo $_SESSION['username']; ?></li>

    				<li><a href="home_1.php?logout='1'">Sign Out</a></li>
    			<?php endif ?>
    			<?php  if (!isset($_SESSION['username'])) : ?>
					<li><a href="reg_1.php">Sign Up</a></li>
				<?php endif ?>
				<li><a href="About Us.html">About Us</a></li>
				<li><a href="Contact Us.html">Contact Us</a></li>
			</ul>
		</nav>
	</div>

	
	<video align="center" src="Sui-Dhaaga-Made-in-India-Official-Trailer-Varun-Dhawan-Anushka-Sharma-Releasing-28th-Sept.mp4" controls poster="Sui_dhaga_hindi.jpg">Browser doesn't support this video format!</video><br></br>
	<div style="margin-left: 110px; margin-right: 100px; margin-bottom: 50px" >
	<p style="font-family: Papyrus; color:#C9380D; font-size: 40px; font-weight: 700" align="center">SUI DHAGA</p><br>
	<p style="font-family: Papyrus; font-size: 35px; font-weight: 700">Hindi</p><br>
	<p id="round" style="font-family:Impact;"> U</p><br><br>

	<image src="calendar-icon.png" width=50px height=40px><font size=5> <b>28-Sep-2018</b></font></image>&emsp;&emsp;

	<image src="clock_icon.png" width=40px height=35px><font size=5> 2hrs 08mins</font></image> <br><br>

	<image src="ratings_heart.png" width=50px height=40px><font size=6>77%</font></image>
	<br></br>

	<p id="rcorners" style="font-family:Impact">Comedy</p> &emsp;
	<p id="rcorners" style="font-family:Impact"> Drama </p>&emsp;
	<p id="rcorners" style="font-family:Impact">Romance</p>
	

	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	<?php  if (!isset($_SESSION['username'])) : ?>
		<input type="button" value="BOOK YOUR TICKETS!" onclick="f1()" style="background-color:#2E86C1; font-size: 20px; padding: 10px" >
	<?php endif ?>
	<?php  if (isset($_SESSION['username'])) : ?>
		<a href="theaters4.php" class="book">BOOK YOUR TICKETS!</a>
	<?php endif ?>
	<br><br>


	<h2 style="color:#A93226"> Synopsis</h2><br>
	<blockquote id="synopsis" style="font-family:Segoe Script">Sui Dhaaga - Made in India recounts the journey of an honest man, who rises from his humble beginnings to become a celebrated social entrepreneur. A heartwarming story of pride, perseverance and self-reliance, the film talks about the need of social entrepreneurship as a tool for the social and economic development of our artisans, who are living their life on the margins due to the changing times.


</blockquote>

	<br></br>

	<div align="center">

	<h2 style="color:#A93226"> User Reviews</h2><br>
	<p style="color:#3498DB"><font size=4><b>Saket</b></font></p><br>
	<font size=3><b>

Totally MAD in India 😂✌️</b></font><br>
	<blockquote><font size="2">Proper show of North Side, the culture, taste, odd delimas, grounded, emotional feel, Varuns comic timing, Anushkas Transformation!!! what else... Sab bhadiya hai✌️</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>Mayank</b></font></p><br>
	<font size=3><b>fabulous in the world</b></font><br>
	<blockquote><font size="2">short movie with great message !superb act by both characters filled with laughter n sense 😊 everyone should go n watch movies that gives motivation to do something big 👌</blockquote>

<br>

<p style="color:#3498DB"><font size=4><b>Nasir</b></font></p><br>
	<font size=3><b>Super hit</b></font><br>
	<blockquote><font size="2">This Is Movie Is A Sweet And Simple Love Story!! Screenplay, Acting And Story Is Awesome 😘 Varun & Anushka Has Done Brilliant Performance 😘 I Recommend Everyone To Watch This Movie!!</blockquote>

<br>

	</div>

	</div>

	<script type="text/javascript">
		function f1()
		{
			alert("Please Sign Up to continue!");
		}
		
	</script>
</body>
</html>