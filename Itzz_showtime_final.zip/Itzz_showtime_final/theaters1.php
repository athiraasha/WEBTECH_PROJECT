<?php 
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Theaters List 1</title>
	<link rel="shortcut icon" href="clapboard.png">

	<style type="text/css">
		#theaters
		{
			box-sizing:border-box;
			width:600px;
			height: 170px;
    		border: 1px solid black;
  		}

  		#main{
	width: 100%;
	height:11vh;
}
nav{
	z-index: 1;
	width: 100%;
	height: 65px;
	background-color: #000;
	line-height: 65px;
	position: fixed;
	top: 0;
	font-family: Calibri;
	font-size: 17px;
}
nav ul{
	list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
	float: right;
	margin-right: 30px;
}
nav ul li{

	display: inline-block;
	transition: 0.8s all;
}

nav ul li:hover{
	background-color: #f39d1a;
}
nav ul li a{
	
	text-decoration: none;
	color: #fff;
	padding: 30px 30px;

}

  		a.buttons
  		{
  			margin-left: 10px;
  			margin-right: 16px;
  			width: 80px;
  			height: 22px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
  		}

	.rate1
	{
   		display: none;
	}

	.buttons:hover+.rate1
	{
		left: 475px;
   		display: block;
   		position:absolute;
   		top: 140px;
	}

	.rate2
	{
   		display: none;
	}

	.buttons:hover+.rate2
	{
		left: 586px;
   		display: block;
   		position:absolute;
   		top: 140px;
	}

	.rate3
	{
   		display: none;
	}

	.buttons:hover+.rate3
	{
		left: 697px;
   		display: block;
   		position:absolute;
   		top: 140px;
	}

	.rate4
	{
   		display: none;
	}

	.buttons:hover+.rate4
	{
		left: 808px;
   		display: block;
   		position:absolute;
   		top: 140px;
	}
	
	.rate5
	{
   		display: none;
	}

	.buttons:hover+.rate5
	{
		left: 530px;
   		display: block;
   		position:absolute;
   		top: 350px;
	}
	
	.rate6
	{
   		display: none;
	}

	.buttons:hover+.rate6
	{
		left: 640px;
   		display: block;
   		position:absolute;
   		top: 350px;
	}
	
	.rate7
	{
   		display: none;
	}

	.buttons:hover+.rate7
	{
		left: 750px;
   		display: block;
   		position:absolute;
   		top: 350px;
	}

	.rate8
	{
   		display: none;
	}

	.buttons:hover+.rate8
	{
		left: 475px;
   		display: block;
   		position:absolute;
   		top: 550px;
	}

	.rate9
	{
   		display: none;
	}

	.buttons:hover+.rate9
	{
		left: 586px;
   		display: block;
   		position:absolute;
   		top: 550px;
	}

	.rate10
	{
   		display: none;
	}

	.buttons:hover+.rate10
	{
		left: 697px;
   		display: block;
   		position:absolute;
   		top: 550px;
	}

	.rate11
	{
   		display: none;
	}

	.buttons:hover+.rate11
	{
		left: 808px;
   		display: block;
   		position:absolute;
   		top: 550px;
	}

	.rate12
	{
   		display: none;
	}

	.buttons:hover+.rate12
	{
		left: 475px;
   		display: block;
   		position:absolute;
   		top: 760px;
	}

	.rate13
	{
   		display: none;
	}

	.buttons:hover+.rate13
	{
		left: 586px;
   		display: block;
   		position:absolute;
   		top: 760px;
	}

	.rate14
	{
   		display: none;
	}

	.buttons:hover+.rate14
	{
		left: 697px;
   		display: block;
   		position:absolute;
   		top: 760px;
	}

	.rate15
	{
   		display: none;
	}

	.buttons:hover+.rate15
	{
		left: 808px;
   		display: block;
   		position:absolute;
   		top: 760px;
	}

	.rate16
	{
   		display: none;
	}

	.buttons:hover+.rate16
	{
		left: 585px;
   		display: block;
   		position:absolute;
   		top: 965px;
	}

	.rate17
	{
   		display: none;
	}

	.buttons:hover+.rate17
	{
		left: 695px;
   		display: block;
   		position:absolute;
   		top: 965px;
	}
	
	</style>

</head>
<body>

	<div id="main">
		<nav>
		<img src="itzz_showtime_final.jpg" width="65px" height="65px">
			<ul>
				
				<?php  if (isset($_SESSION['username'])) : ?>
					
					<li style="color: white;"><img src="login_icon.jpg" width="30" height="30">Hi,<?php echo $_SESSION['username']; ?></li>

    				<li><a href="home_1.php?logout='1'">Sign Out</a></li>
    			<?php endif ?>
    			<?php  if (!isset($_SESSION['username'])) : ?>
					<li><a href="reg_1.php">Sign Up</a></li>
				<?php endif ?>
				<li><a href="About Us.html">About Us</a></li>
				<li><a href="Contact Us.html">Contact Us</a></li>
			</ul>
		</nav>
	</div>

	<div align="center">
	
		<div align="center" id="theaters">
			<p style="font-family: Ink Free;font-size: 30px; color: #0F8D99"><b>Abhinay Theatre: Gandhi Nagar</b></p>
			<br>

			<a href="seating_arr1.php" title="#rate1" class="buttons">10:30 am</a>
			<div class="rate1">
				<p style="font-family: Segoe Print">Rs.300</p>
			</div>	
			<a href="seating_arr4.php" title="#rate2" class="buttons">1:00 pm</a>
			<div class="rate2">
				<p style="font-family: Segoe Print">Rs.350</p>
			</div>
			<a href="seating_arr3.php" title="#rate3" class="buttons">5:00 pm</a>
			<div class="rate3">
				<p style="font-family: Segoe Print">Rs.280</p>
			</div>
			<a href="seating_arr5.php" title="#rate4" class="buttons">9:45 pm</a>
			<div class="rate4">
				<p style="font-family: Segoe Print">Rs.400</p>
			</div>
		</div>

		<br><br>

		<div align="center" id="theaters">
			<p style="font-family: Ink Free;font-size: 30px; color: #0F8D99"><b>Balaji Digital 2K Cinema: Tavarekere</b></p>
			<br>

			<a href="seating_arr2.php" title="#rate5" class="buttons">10:00 am</a>
			<div class="rate5">
				<p style="font-family: Segoe Print">Rs.250</p>
			</div>
			<a href="seating_arr3.php" title="#rate6" class="buttons">1:20 pm</a>
			<div class="rate6">
				<p style="font-family: Segoe Print">Rs.280</p>
			</div>
			<a href="seating_arr1.php" title="#rate7" class="buttons">5:30 pm</a>
			<div class="rate7">
				<p style="font-family: Segoe Print">Rs.300</p>
			</div>
		</div>

		<br><br>

		<div align="center" id="theaters">
			<p style="font-family: Ink Free;font-size: 30px; color: #0F8D99"><b>Cinepolis: Binnypet Mall</b></p>
			<br>

			<a href="seating_arr3.php" title="#rate8" class="buttons">8:00 am</a>
			<div class="rate8">
				<p style="font-family: Segoe Print">Rs.280</p>
			</div>
			<a href="seating_arr4.php" title="#rate9" class="buttons">11:20 am</a>
			<div class="rate9">
				<p style="font-family: Segoe Print">Rs.350</p>
			</div>
			<a href="seating_arr1.php" title="#rate10" class="buttons">3:15 pm</a>
			<div class="rate10">
				<p style="font-family: Segoe Print">Rs.300</p>
			</div>
			<a href="seating_arr4.php" title="#rate11" class="buttons">7:30 pm</a>
			<div class="rate11">
				<p style="font-family: Segoe Print">Rs.350</p>
			</div>
		</div>

		<br><br>

		<div align="center" id="theaters">
			<p style="font-family: Ink Free;font-size: 30px; color: #0F8D99"><b>Eshwari Digital 2K Cinema: Banashankari</b></p>
			<br>

			<a href="seating_arr2.php" title="#rate12" class="buttons">8:30 am</a>
			<div class="rate12">
				<p style="font-family: Segoe Print">Rs.250</p>
			</div>
			<a href="seating_arr1.php" title="#rate13" class="buttons">12:00 pm</a>
			<div class="rate13">
				<p style="font-family: Segoe Print">Rs.300</p>
			</div>
			<a href="seating_arr4.php" title="#rate14" class="buttons">3:15 pm</a>
			<div class="rate14">
				<p style="font-family: Segoe Print">Rs.350</p>
			</div>
			<a href="seating_arr3.php" title="#rate15" class="buttons">6:00 pm</a>
			<div class="rate15">
				<p style="font-family: Segoe Print">Rs.280</p>
			</div>
		</div>

		<br><br>

		<div align="center" id="theaters">
			<p style="font-family: Ink Free;font-size: 30px; color: #0F8D99"><b>Goverdhan Theatre: Yeshwanthpur</b></p>
			<br>

			<a href="seating_arr2.php" title="#rate16" class="buttons">10:30 am</a>
			<div class="rate16">
				<p style="font-family: Segoe Print">Rs.250</p>
			</div>
			<a href="seating_arr1.php" title="#rate17" class="buttons">5:00 pm</a>
			<div class="rate17">
				<p style="font-family: Segoe Print">Rs.300</p>
			</div>
		</div>
	</div>
</div>
</body>
</html>