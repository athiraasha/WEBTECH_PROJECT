<?php 
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Katheyondu Shuruvagide</title>
	<link rel="stylesheet" type="text/css" href="ticket_booking_button.css">
	<link rel="shortcut icon" href="clapboard.png">

<style type="text/css">

		a.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 10px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}
	
		video
		{
			text-align:center;
			margin:0 auto;
			display:block;
			object-fit: inherit;
			max-height:400px;
			min-width: 100%;
			object-fit: fill;
		}

		#rcorners
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 2px solid #909497;
    		padding: 20px; 
    		width: 50px;
    		height: 10px; 
    		text-align:center;   
		}
		
		#round
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 4px solid #909497;
    		padding: 20px 20px 22px 20px; 
    		width: 6px;
    		height: 6px; 

</style>

<style>
	
	*{
		margin: 0;
		padding:0;
		font-family: verdana;
	}
#main{
	width: 100%;
	height:15vh;
}
nav{
	z-index:1;
	width: 100%;
	height: 80px;
	background-color: #000;
	line-height: 80px;
	position: fixed;
	top: 0;
}
nav ul{
	float: right;
	margin-right: 30px;
}
nav ul li{
	list-style-type: none;
	display: inline-block;
	transition: 0.8s all;
}

nav ul li:hover{
	background-color: #f39d1a;
}
nav ul li a{
	text-decoration: none;
	color: #fff;
	padding: 30px

}

#synopsis
{
	font-size: 20px;
	font-weight: 700;
}

</style>
</head>
<body>
	<div id="main">
		<nav>
		<img src="itzz_showtime_final.jpg" width="100" height="80">
			<ul>
				
				<?php  if (isset($_SESSION['username'])) : ?>
					
					<li style="color: white;"><img src="login_icon.jpg" width="30" height="30">Hi,<?php echo $_SESSION['username']; ?></li>

    				<li><a href="home_1.php?logout='1'">Sign Out</a></li>
    			<?php endif ?>
    			<?php  if (!isset($_SESSION['username'])) : ?>
					<li><a href="reg_1.php">Sign Up</a></li>
				<?php endif ?>
				<li><a href="About Us.html">About Us</a></li>
				<li><a href="Contact Us.html">Contact Us</a></li>
			</ul>
		</nav>
	</div>

	
	<video align="center" src="(HDvd9.co)_Katheyondu-Shuruvagide---Official-Trailer--Diganth-Pooja--Senna--Rakshit-Shetty-Pushkara-Vinod.mp4" controls poster="Katheyondu-Shuruvagide-kannada.jpg">Browser doesn't support this video format!</video><br></br>
	<div style="margin-left: 110px; margin-right: 100px; margin-bottom: 50px" >
	<p style="font-family: Papyrus; color:#C9380D; font-size: 40px; font-weight: 700" align="center">KATHEYONDU SHURUVAGIDE</p><br>
	<p style="font-family: Papyrus; font-size: 35px; font-weight: 700">Kannada</p><br>

	<p id="round" style="font-family:Impact;"> UA</p><br><br>
	
	<image src="calendar-icon.png" width=45px height=35px><font size=5><b> 03-Aug-2018</b></font></image> &emsp;&emsp;

	<image src="clock_icon.png" width=40px height=35px><font size=5> 2hrs 24mins</font></image> <br><br>

	<image src="ratings_heart.png" width=40px height=30px><font size=6>70%</font></image>
	<br></br>

	<p id="rcorners" style="font-family:Impact"> Drama</p> &emsp;
	<p id="rcorners" style="font-family:Impact"> Romance</p>&emsp;
	

	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	<?php  if (!isset($_SESSION['username'])) : ?>
		<input type="button" value="BOOK YOUR TICKETS!" onclick="f1()" style="background-color:#2E86C1; font-size: 20px; padding: 10px" >
	<?php endif ?>
	<?php  if (isset($_SESSION['username'])) : ?>
		<a href="theaters3.php" class="book">BOOK YOUR TICKETS!</a>
	<?php endif ?>
	<br><br>


	<h2 style="color:#A93226"> Synopsis</h2><br>
	<blockquote id="synopsis" style="font-family:Segoe Script">A young resort owner, Tarun, is going through a rough time and tries to deal with disappointments, failures, and struggles of his life. In the process of doing so, he strikes up a great bond with a resort guest, Tanya. Will this bond help them to find a new meaning of love and life?</blockquote>

	<br></br>

	<div align="center">

	<h2 style="color:#A93226"> User Reviews</h2><br>

	<p style="color:#3498DB"><font size=4><b>Prasad Hegde</b></font></p><br>
	<font size=3><b>Interesting story</b></font><br>
	<blockquote><font size="2">Superb movie ..!! this is one of a kind that holds the curiosity till the end. narrating the story is unique, director takes the distinction for that. background scores, heart touching dialogues, diganth acting are brilliant, except for the two uncompleted story line of pedro and uncle, which lasts even after coming out of the theatre, movie is a one of the classy and must watch of recent times....</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>Chetan Shetty</b></font></p><br>
	<font size=3><b>Good Movie</b></font><br>
	<blockquote><font size="2">It’s been long that such a beautifully done movie been released in Kannada industry. Excellent story narration with some scenic places in and around Karnataka has been used in a very clever way. Who says you need to go out stations to shoot such beautiful locations. Well done director and story writter👍....</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>Tulsi</b></font></p><br>
	<font size=3><b>Brilliant</b></font><br>
	<blockquote><font size="2">Dis one is brilliant! Jus love it! Diagnth the charmer😍 is back! Stellar casting! Cinematography is jus to next level in kfi! Direction is amazing and the music is so Soo soulful 👍 hats of to rakshit n pushkar for this movie! It''s a must watch.😍😍...</blockquote>

<br>


	</div>

	</div>

	<script type="text/javascript">
		function f1()
		{
			alert("Please Sign Up to continue!");
		}
		
	</script>
</body>
</html>