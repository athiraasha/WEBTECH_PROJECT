<?php 
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>K.G.F</title>
	<link rel="shortcut icon" href="clapboard.png">

<style type="text/css">
	
		video
		{
			text-align:center;
			margin:0 auto;
			display:block;
			object-fit: inherit;
			max-height:400px;
			min-width: 100%;
			object-fit: fill;
		}

		#rcorners
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 2px solid #909497;
    		padding: 20px; 
    		width: 50px;
    		height: 10px; 
    		text-align:center;   
		}

</style>

<style>
	
	*{
		margin: 0;
		padding:0;
		font-family: verdana;
	}
#main{
	width: 100%;
	height:15vh;
}
nav{
	z-index:1;
	width: 100%;
	height: 80px;
	background-color: #000;
	line-height: 80px;
	position: fixed;
	top: 0;
}
nav ul{
	float: right;
	margin-right: 30px;
}
nav ul li{
	list-style-type: none;
	display: inline-block;
	transition: 0.8s all;
}

nav ul li:hover{
	background-color: #f39d1a;
}
nav ul li a{
	text-decoration: none;
	color: #fff;
	padding: 30px

}

#synopsis
{
	font-size: 20px;
	font-weight: 700;
}

</style>
</head>
<body>
	<div id="main">
		<nav>
		<img src="itzz_showtime_final.jpg" width="100" height="80">
			<ul>
				
				<?php  if (isset($_SESSION['username'])) : ?>
					
					<li style="color: white;"><img src="login_icon.jpg" width="30" height="30">Hi,<?php echo $_SESSION['username']; ?></li>

    				<li><a href="home_1.php?logout='1'">Sign Out</a></li>
    			<?php endif ?>
    			<?php  if (!isset($_SESSION['username'])) : ?>
					<li><a href="reg_1.php">Sign Up</a></li>
				<?php endif ?>
				<li><a href="About Us.html">About Us</a></li>
				<li><a href="Contact Us.html">Contact Us</a></li>
			</ul>
		</nav>
	</div>

	<video align="center" src="(HDvd9.co)_KGF--Official-Trailer-Movie-Release-Date--Official-Teaser--Yash--Prashanth-Neel--Ravi-Basrur.mp4" controls poster="kgf-kannada.jpg">Browser doesn't support this video format!</video><br></br>

	<div style="margin-left: 110px; margin-right: 100px; margin-bottom: 50px" >
	<p style="font-family: Papyrus; color:#C9380D; font-size: 40px; font-weight: 700" align="center">K.G.F</p><br>
	
	<image src="calendar-icon.png" width=50px height=40px><font size=5><b> 16-Nov-2018</b></font></image> <br><br>
	
	
	<input type="image" src="thumbs-up_icon.png" width=50px height=40px onclick="f1()"><h2 id="like"> 0</h2></input>
	<br></br>

	<p id="rcorners" style="font-family:Impact"> Action</p> &emsp;
	<p id="rcorners" style="font-family:Impact"> Romance </p>&emsp;
	

	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	

	<br><br>


	<h2 style="color:#A93226"> Synopsis</h2><br>
	<blockquote id="synopsis" style="font-family:Segoe Script">A period drama narrates the 17000-year-old history of oppressed waging wars against their oppressors. Set in the early 80s, KGF - the first chapter centers the protagonist who leads a battle against oppressors.</blockquote>

	<br></br>

	<div align="center">

	<h2 style="color:#A93226">User Reviews</h2><br>

	<font size=3><b>No users have reviewed this movie yet!</b></font><br>


	</div>

	</div>
	<script type="text/javascript">
		var count=0;
		function f1()
		{
			count++;
			var a=document.getElementById('like');
			a.textContent=count;
		}
	</script>

</body>
</html>