<?php
	$servername="localhost";
	$username="root";
	$password="";
	$conn=mysqli_connect($servername,$username,$password);
	//check connection
	if(!$conn)
	{
		die("connection failed:".mysqli_connect_error());
	}
	echo "connected successfully<br>";
	//create database
	$sql="CREATE DATABASE registration";
	if(mysqli_query($conn,$sql))
	{
		echo "database created successfully";
	}
	else
	{
		echo "error creating database:".mysqli_error($conn);
	}
?>