<?php 
  session_start(); 

  
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login_1.php");
  }
?>



<!DOCTYPE html>
<html>
<head>
	<title>itzz showtime</title>
	<link rel="stylesheet" type="text/css" href="css_nav.css">
	<link rel="shortcut icon" href="clapboard.png">
	<style>
		* {box-sizing: border-box;}
		body {font-family: Verdana, sans-serif;}
		.mySlides {display: none;}
		.slideshow-container {
 			 max-width: 1000px;
			position: relative;
  			margin: auto;
		}
		#offer{
 			 height: 300px;
 			 width: 141px;
		}
		/* Fading animation */
		.fade {
 			 -webkit-animation-name: fade;
 			 -webkit-animation-duration: 1.5s;
 			 animation-name: fade;
 			 animation-duration: 1.5s;
		}

		@-webkit-keyframes fade {
 		 	from {opacity: .4} 
			to {opacity: 1}
		}

		@keyframes fade {
  			from {opacity: .4} 
  			to {opacity: 1}
		}

		
		
	</style>
</head>
<body>

	<div id="main">
		<nav>
		<img src="itzz_showtime_final.jpg" width="100" height="80">
			<ul>
				<select style="width:500px; height:50px" name="formal" onchange="javascript:handleSelect(this)">
					<option value="" disabled selected>Select your favourite movie!</option>
					<optgroup label="Telugu">
						<option value="#two">Aravinda Sametha Veera Raghava</option>
						<option value="#one">Deva Daasu</option>
						<option value="#thirteen">Geetha Govindam</option>
						<option value="#fourteen">Goodachari</option>
						<option value="#seventeen">Happy Wedding</option>
						<option value="#twentyfive">NOTA</option>
					</optgroup>

					<optgroup label="Kannada">
						<option value="#three">Ambi Ning Vayassaytho</option>
						<option value="#nine">Ayogya</option>
						<option value="#twentyfour">KGF</option>
						<option value="#twentytwo">Katheyondu Shuruvagide</option>
						<option value="#twentythree">Kavalu Daari</option>					
						<option value="#four">The Villain</option>
					</optgroup>

					<optgroup label="Tamil">
						<option value="#six">'96</option>
						<option value="#five">2.0</option>					
						<option value="#eleven">Chekka Chivantha Vaanam</option>
						<option value="#twelve">Dhruva Natchathiram</option>
						<option value="#twenty">Kaala</option>
						<option value="#twentyone">Kadaikutty Singham</option>
					</optgroup>

					<optgroup label="English">
						<option value="#seven">Ant-man And The Wasp</option>
						<option value="#eight">Avengers Infinity War</option>
						<option value="#ten">Black Panther</option>
						<option value="#fifteen">Goosebumps-2</option>
						<option value="#sixteen">Halloween-2018</option>
						<option value="#ninteen">Incredibles-2</option>
					</optgroup>
					<optgroup label="Hindi">					
						<option value="#twentyseven">Andhadhun</option>
						<option value="#twentysix">Dhadak</option>
						<option value="#twentyeight">Helicopter Eela</option>
						<option value="#twentynine">Love Yatri</option>
						<option value="#thirty">Namastey England</option>
						<option value="#thirtyone">Sui Dhaga</option>
				</select>
				
				<?php  if (isset($_SESSION['username'])) : ?>
					
					<li style="color: white;"><img src="login_icon.jpg" width="30" height="30">Hi,<?php echo $_SESSION['username']; ?></li>

    				<li><a href="home_1.php?logout='1'">Sign Out</a></li>
    			<?php endif ?>
    			<?php  if (!isset($_SESSION['username'])) : ?>
					<li><a href="reg_1.php">Sign Up</a></li>
				<?php endif ?>
				<li><a href="About Us.html">About Us</a></li>
				<li><a href="Contact Us.html">Contact Us</a></li>
			</ul>
		</nav>
	</div>
	
	

	<div class="slideshow-container">

		<div class="mySlides fade">
 		 	<img src="hd_offer1.jpg" style="width:100%" id="offer">
		</div>

		<div class="mySlides fade">
 		 	<img src="hd_offer2.jpg" style="width:100%" id="offer">
		</div>

		<div class="mySlides fade">
  			<img src="hd_offer3.jpg" style="width:100%" id="offer">
		</div>

		<div class="mySlides fade">
  			<img src="hd_offer4.jpg" style="width:100%" id="offer">
		</div>

		<div class="mySlides fade">
  			<img src="hd_offer5.jpg" style="width:100%" id="offer">
		</div>

	</div>

	<br><br>
<div style="margin-left:190px" >
	<div id="posters">

		<!--Telugu-->
		<a href="Aravinda_Sametha.php
"><img style="border-radius: 25px" id="two" src="Aravinda-Sametha2_telgu.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		
		<a href="Deva_Daasu.php
"><img style="border-radius: 25px" id="one" src="Devadas2_telgu.jpg" width=300px height=380px/></a>


		&emsp;&nbsp;

		<a href="geetha_govindam.php"><img style="border-radius: 25px" id="thirteen" src="geetha-govindam-telugu.jpg" width=300px height=380px/></a>

		<br><br><br>

		<a href="goodachari.php"><img style="border-radius: 25px" id="fourteen" src="goodachari-telugu.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="happy_wedding.php"><img style="border-radius: 25px" id="seventeen" src="happy-wedding-telugu.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="nota.php"><img style="border-radius: 25px" id="twentyfive" src="NOTA-telugu.jpg" width=300px height=380px/></a>


		<br><br><br>
		<!--Kannada-->
		<a href="ambi_ning_vayassaytho.php"><img style="border-radius: 25px" id="three" src="ambi-ning-vayassaytho-kannada.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="ayogya.php"><img style="border-radius: 25px" id="nine" src="ayogya-kannada.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="katheyondu_shuruvagide.php"><img style="border-radius: 25px" id="twentytwo" src="Katheyondu-Shuruvagide-kannada.jpg" width=300px height=380px/></a>


		<br><br><br>

		<a href="kavaludaari.php"><img style="border-radius: 25px" id="twentythree" src="kavalu-daari-kannada.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="kgf.php"><img style="border-radius: 25px" id="twentyfour" src="kgf-kannada.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;


		<a href="the_villain.php"><img style="border-radius: 25px" id="four" src="The-Villain-Kannada.jpg" width=300px height=380px/></a>


		<br><br><br>

		<!--Tamil-->
		<a href="96.php"><img style="border-radius: 25px" id="six" src="'96-tamil-movie.jpg" width=300px height=380px/></a>
		
		&emsp;&nbsp;

		<a href="2.0.php"><img style="border-radius: 25px" id="five" src="2.0-tamil.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="chekka_chivantha_vaanam.php"><img style="border-radius: 25px" id="eleven" src="chekka-chivantha-vaanam-tamil.jpg" width=300px height=380px/></a>

		<br><br><br>
		<a href="dhruva_natchathiram.php"><img style="border-radius: 25px" id="twelve" src="dhruva-natchathiram-tamil.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="kaala.php"><img style="border-radius: 25px" id="twenty" src="kaala-tamil.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="kadaikutty_singham.php"><img style="border-radius: 25px" id="twentyone" src="kadaikutty-singham-tamil.jpg" width=300px height=380px/></a>


		<br><br><br>
		<!--English-->

		<a href="antman_and_the_wasp.php"><img style="border-radius: 25px" id="seven" src="antman-and-the-wasp-english.png" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="avengers.php"><img style="border-radius: 25px" id="eight" src="avengers-infinity-war-english.png" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="black_panther.php"><img style="border-radius: 25px" id="ten" src="BlackPanther-english.jpg" width=300px height=380px/></a>

		<br><br><br>
		<a href="goosebumps2.php"><img style="border-radius: 25px" id="fifteen" src="Goosebumps-2-english.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="halloween.php"><img style="border-radius: 25px" id="sixteen" src="Halloween-2018-english.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="incredibles2.php"><img style="border-radius: 25px" id="ninteen" src="incredibles-2-english.jpeg" width=300px height=380px/></a>


		<br><br><br>
		<!--Hindi-->
		<a href="andhadhun.php"><img style="border-radius: 25px" id="twentyseven" src="Andhadhun_hindi.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="dhadak.php"><img style="border-radius: 25px" id="twentysix" src="Dhadak_hindi.jpg" width=300px height=380px/></a>


		&emsp;&nbsp;

		<a href="helicopter_eela.php"><img style="border-radius: 25px" id="twentyeight" src="HelicopterEela_hindi.jpg" width=300px height=380px/></a>

		<br><br><br>

		<a href="love_yatri.php"><img style="border-radius: 25px" id="twentynine" src="LoveYatri_hindi.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="namaste_england.php"><img style="border-radius: 25px" id="thirty" src="namastey-england_hindi.jpg" width=300px height=380px/></a>

		&emsp;&nbsp;

		<a href="sui_dhaga.php"><img style="border-radius: 25px" id="thirtyone" src="Sui_dhaga_hindi.jpg" width=300px height=380/></a>


		<br><br><br>

	</div>

</div>
	<br>
	<script type="text/javascript">
	var slideIndex = 0;
	showSlides();

	function showSlides() {
	    var i;
	    var slides = document.getElementsByClassName("mySlides fade");
	    var dots = document.getElementsByClassName("dot");
	    for (i = 0; i < slides.length; i++) {
	       slides[i].style.display = "none";  
	    }
	    slideIndex++;
	    if (slideIndex > slides.length) {slideIndex = 1}    
	    slides[slideIndex-1].style.display = "block";  
	    setTimeout(showSlides, 2000); // Change image every 2 seconds
	}
	</script>

	<script type="text/javascript">
		function handleSelect(elm)
		{
			window.location=elm.value;
		}
	</script>



</body>
</html>