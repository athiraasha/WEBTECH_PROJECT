<?php 
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Geetha Govindam</title>
	<link rel="shortcut icon" href="clapboard.png">

<style type="text/css">
		a.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 10px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}
	
		video
		{
			text-align:center;
			margin:0 auto;
			display:block;
			object-fit: inherit;
		
    		max-height: 400px;
    		min-width: 100%;
   			object-fit: fill;
		}

		#rcorners
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 2px solid #909497;
    		padding: 20px; 
    		width: 50px;
    		height: 10px; 
    		text-align:center;   
		}

</style>

<style>
	
	*{
		margin: 0;
		padding:0;
		font-family: verdana;
	}
#main{
	width: 100%;
	height:15vh;
}
nav{
	z-index:1;
	width: 100%;
	height: 80px;
	background-color: #000;
	line-height: 80px;
	position: fixed;
	top: 0;
}
nav ul{
	float: right;
	margin-right: 30px;
}
nav ul li{
	list-style-type: none;
	display: inline-block;
	transition: 0.8s all;
}

nav ul li:hover{
	background-color: #f39d1a;
}
nav ul li a{
	text-decoration: none;
	color: #fff;
	padding: 30px

}

#synopsis
{
	font-size: 20px;
	font-weight: 700;
}
#round
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 4px solid #909497;
    		padding: 20px 20px 22px 20px; 
    		width: 6px;
    		height: 6px; 

    		   
		}

</style>
</head>
<body>
	<div id="main">
		<nav>
		<img src="itzz_showtime_final.jpg" width="100" height="80">
			<ul>
				
				<?php  if (isset($_SESSION['username'])) : ?>
					
					<li style="color: white;"><img src="login_icon.jpg" width="30" height="30">Hi,<?php echo $_SESSION['username']; ?></li>

    				<li><a href="home_1.php?logout='1'">Sign Out</a></li>
    			<?php endif ?>
    			<?php  if (!isset($_SESSION['username'])) : ?>
					<li><a href="reg_1.php">Sign Up</a></li>
				<?php endif ?>
				<li><a href="About Us.html">About Us</a></li>
				<li><a href="Contact Us.html">Contact Us</a></li>
			</ul>
		</nav>
	</div>

	
	<video align="center" src="(Hdvdz.com)_Geetha-Govindam-Theatrical-Trailer--Vijay-Davarakonda-Rashmika-Mandanna-.mp4" controls poster="geetha-govindam-telugu.jpg">Browser doesn't support this video format!</video><br></br>
	<div style="margin-left: 110px; margin-right: 100px; margin-bottom: 50px" >
	<p style="font-family: Papyrus; color:#C9380D; font-size: 40px; font-weight: 700" align="center">GEETHA GOVINDAM</p><br>
	<p style="font-family: Papyrus; font-size: 35px; font-weight: 700">Telugu</p><br>
	<p id="round" style="font-family:Impact;"> UA</p><br><br>
	<image src="calendar-icon.png" width=50px height=40px><font size=5> <b>15-Aug-2018</b></font></image>&emsp;&emsp;

	<image src="clock_icon.png" width=40px height=35px><font size=5> 2hrs 28mins</font></image> <br><br>

	<image src="ratings_heart.png" width=50px height=40px><font size=6>86%</font></image>
	<br></br>

	<p id="rcorners" style="font-family:Impact">Comedy</p> &emsp;
	<p id="rcorners" style="font-family:Impact"> Drama </p>&emsp;
	<p id="rcorners" style="font-family:Impact">Romance</p>
	

	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	<?php  if (!isset($_SESSION['username'])) : ?>
		<input type="button" value="BOOK YOUR TICKETS!" onclick="f1()" style="background-color:#2E86C1; font-size: 20px; padding: 10px" >
	<?php endif ?>
	<?php  if (isset($_SESSION['username'])) : ?>
		<a href="theaters1.php" class="book">BOOK YOUR TICKETS!</a>
	<?php endif ?>
	<br><br>


	<h2 style="color:#A93226"> Synopsis</h2><br>
	<blockquote id="synopsis" style="font-family:Segoe Script">With good acting, great humour and fine music, director Parasuram gets it right with Geetha Govindam

</blockquote>

	<br></br>

	<div align="center">

	<h2 style="color:#A93226"> User Reviews</h2><br>
	<p style="color:#3498DB"><font size=4><b>Vasudevan</b></font></p><br>
	<font size=3><b>Feel good movie</b></font><br>
	<blockquote><font size="2">Decent! Class! Rashmika did a great great job, she actually did a Samantha????????She is heart of the movie, People who don’t like Vijay’s attitude (I’m one of them) will love him in this movie.. don’t miss it!!</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>Praneet</b></font></p><br>
	<font size=3><b>Awesome Movie</b></font><br>
	<blockquote><font size="2">Awesome Awesome movie you people should watch this movie.. Thier pair is so awesome... Thankful to the director for giving opportunity to vijay devarakonda</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>Harsha</b></font></p><br>
	<font size=3><b>inkem inkem inkem kavali????</b></font><br>
	<blockquote><font size="2">enjoyed the whole movie. fantastic acting from the leads #VD and the crush of karnataka #RM 100% entertainment assured and this is what the movie lovers like to watch. beautiful narration for the two beautiful actors. keep counting for more entertainment movies later in the 2nd half of 2018. in love from geetha govindam #cheers#VDRM
</blockquote>

<br>

	</div>

	</div>
	<script type="text/javascript">
		function f1()
		{
			alert("Please Sign Up to continue!");
		}
		
	</script>
</body>
</html>