<?php 
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Chekka Chivantha Vaanam</title>
	<link rel="stylesheet" type="text/css" href="ticket_booking_button.css">
	<link rel="shortcut icon" href="clapboard.png">

<style type="text/css">

		a.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 10px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}
	

	
		video
		{
			text-align:center;
			margin:0 auto;
			display:block;
			
			object-fit: inherit;

			max-height: 400px;
    		min-width: 100%;
   			object-fit: fill;
		}

		#rcorners
		{
			display:inline-block;
    		border-radius: 50px;
    		border: 2px solid #909497;
    		padding: 20px; 
    		width: 50px;
    		height: 10px; 
    		text-align:center;   
		}

		#round
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 4px solid #909497;
    		padding: 20px 20px 22px 20px; 
    		width: 6px;
    		height: 6px; 
		}

</style>

<style>
	
	*{
		margin: 0;
		padding:0;
		font-family: verdana;
	}
#main{
	width: 100%;
	height:15vh;
}
nav{
	z-index:1;
	width: 100%;
	height: 80px;
	background-color: #000;
	line-height: 80px;
	position: fixed;
	top: 0;
}
nav ul{
	float: right;
	margin-right: 30px;
}
nav ul li{
	list-style-type: none;
	display: inline-block;
	transition: 0.8s all;
}

nav ul li:hover{
	background-color: #f39d1a;
}
nav ul li a{
	text-decoration: none;
	color: #fff;
	padding: 30px

}

#synopsis
{
	font-size: 20px;
	font-weight: 700;
}

</style>
</head>
<body>
	<div id="main">
		<nav>
		<img src="itzz_showtime_final.jpg" width="100" height="80">
			<ul>
				
				<?php  if (isset($_SESSION['username'])) : ?>
					
					<li style="color: white;"><img src="login_icon.jpg" width="30" height="30">Hi,<?php echo $_SESSION['username']; ?></li>

    				<li><a href="home_1.php?logout='1'">Sign Out</a></li>
    			<?php endif ?>
    			<?php  if (!isset($_SESSION['username'])) : ?>
					<li><a href="reg_1.php">Sign Up</a></li>
				<?php endif ?>
				<li><a href="About Us.html">About Us</a></li>
				<li><a href="Contact Us.html">Contact Us</a></li>
			</ul>
		</nav>
	</div>

	
	<video align="center" src="(HDvd9.co)_CHEKKA-CHIVANTHA-VAANAM--Official-Trailer---Tamil--Mani-Ratnam--Lyca-Productions--Madras-Talkies.mp4" controls poster="chekka-chivantha-vaanam-tamil.jpg">Browser doesn't support this video format!</video><br></br>

	<div style="margin-left: 110px; margin-right: 100px; margin-bottom: 50px" >
		<p style="font-family: Papyrus; color:#C9380D; font-size: 40px; font-weight: 700" align="center">CHEKKA CHIVANTHA VAANAM</p><br>

	<p style="font-family: Papyrus; font-size: 35px; font-weight: 700">Tamil</p><br>

	<p id="round" style="font-family:Impact;"> UA</p><br><br>

	<image src="calendar-icon.png" width=50px height=40px><font size=5><b> 27-Sept-2018</b></font></image> &emsp;&emsp;

	<image src="clock_icon.png" width=40px height=35px><font size=5> 2hrs 24mins</font></image> <br><br>

	<image src="ratings_heart.png" width=50px height=40px><font size=6>78%</font></image>
	<br></br>

	<p id="rcorners" style="font-family:Impact"> Action</p> &emsp;
	<p id="rcorners" style="font-family:Impact"> Crime</p>&emsp;
	<p id="rcorners" style="font-family:Impact"> Thriller</p>

	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	<?php  if (!isset($_SESSION['username'])) : ?>
		<input type="button" value="BOOK YOUR TICKETS!" onclick="f1()" style="background-color:#2E86C1; font-size: 20px; padding: 10px" >
	<?php endif ?>
	<?php  if (isset($_SESSION['username'])) : ?>
		<a href="theaters4.php" class="book">BOOK YOUR TICKETS!</a>
	<?php endif ?>
	<br><br>


	<h2 style="color:#A93226"> Synopsis</h2><br>
	<blockquote id="synopsis" style="font-family:Segoe Script"> Senapathi's sons have always desired the power and success their father has enjoyed. So, when a coveted spot in the family business - that of city's most influential gangster - is up for grabs, the three brothers are lured into a collision course. Blood ties will unravel as a bloody battle for power begins.</blockquote>

	<br></br>

	<div align="center">

	<h2 style="color:#A93226"> User Reviews</h2><br>

	<p style="color:#3498DB"><font size=4><b>Siva Das</b></font></p><br>
	<font size=3><b>Awesome Movie</b></font><br>
	<blockquote><font size="2">awesome movie again by Mani ratnam.. superb acting by the crew. my ratings for the movie 10/10 👌👌👌👌..aravind swami awesome acting ... Vijay sethupathi vere level acting.. a superb movie...</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>Glitson</b></font></p><br>
	<font size=3><b>Below Average</b></font><br>
	<blockquote><font size="2">personally I don't like the movie. film is full of hype. Even though it is a gangster movie it is not a thriller type. scene are very lagging. contain so many characters. director only concentrating to placing them in film. i can only give the review as good film or bad film. not like making is good, stunts are good, actors are good.</blockquote>
<br>

	<p style="color:#3498DB"><font size=4><b>Parthi</b></font></p><br>
	<font size=3><b>CVV</b></font><br>
	<blockquote><font size="2">simbu and vijaya sethupathi mass entry👍and maniratnam super and music ultimate arrahman.and editing nice song all good😘😘😘😘😘😘😘😎😎😎👍👍👍👍👍👌</blockquote>
<br>

	</div>

	</div>
	<script type="text/javascript">
		function f1()
		{
			alert("Please Sign Up to continue!");
		}
		
	</script>

</body>
</html>