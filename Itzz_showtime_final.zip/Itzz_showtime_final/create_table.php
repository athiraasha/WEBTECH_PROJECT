<?php
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="registration";
	$conn=mysqli_connect($servername,$username,$password,$dbname);
	//check connection
	if(!$conn)
	{
		die("connection failed:".mysqli_connect_error());
	}
	//sql to create table
	$sql="CREATE TABLE users 
	(name VARCHAR(100),username VARCHAR(100),email VARCHAR(100),password VARCHAR(100))";
	if(mysqli_query($conn,$sql))
	{
		echo "table created successfully";
	}
	else
	{
		echo "error creating table:".mysqli_error($conn);
	}

	