<?php 
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Dhadak</title>
	<link rel="stylesheet" type="text/css" href="ticket_booking_button.css">
	<link rel="shortcut icon" href="clapboard.png">

<style type="text/css">

		a.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 10px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}
	
		video
		{
			text-align:center;
			margin:0 auto;
			display:block;
			
			object-fit: inherit;

			max-height: 400px;
    		min-width: 100%;
   			object-fit: fill;
		}

		#rcorners
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 2px solid #909497;
    		padding: 20px; 
    		width: 50px;
    		height: 10px; 
    		text-align:center;   
		}

		#round
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 4px solid #909497;
    		padding: 20px 20px 22px 20px; 
    		width: 6px;
    		height: 6px; 
		}

</style>

<style>
	
	*{
		margin: 0;
		padding:0;
		font-family: verdana;
	}
#main{
	width: 100%;
	height:15vh;
}
nav{
	z-index:1;
	width: 100%;
	height: 80px;
	background-color: #000;
	line-height: 80px;
	position: fixed;
	top: 0;
}
nav ul{
	float: right;
	margin-right: 30px;
}
nav ul li{
	list-style-type: none;
	display: inline-block;
	transition: 0.8s all;
}

nav ul li:hover{
	background-color: #f39d1a;
}
nav ul li a{
	text-decoration: none;
	color: #fff;
	padding: 30px

}

#synopsis
{
	font-size: 20px;
	font-weight: 700;
}

</style>
</head>
<body>
	<div id="main">
		<nav>
		<img src="itzz_showtime_final.jpg" width="100" height="80">
			<ul>
				
				<?php  if (isset($_SESSION['username'])) : ?>
					
					<li style="color: white;"><img src="login_icon.jpg" width="30" height="30">Hi,<?php echo $_SESSION['username']; ?></li>

    				<li><a href="home_1.php?logout='1'">Sign Out</a></li>
    			<?php endif ?>
    			<?php  if (!isset($_SESSION['username'])) : ?>
					<li><a href="reg_1.php">Sign Up</a></li>
				<?php endif ?>
				<li><a href="About Us.html">About Us</a></li>
				<li><a href="Contact Us.html">Contact Us</a></li>
			</ul>
		</nav>
	</div>

	
	<video align="center" src="Dhadak 2018 Trailer Full Hd.mp4" controls poster="Dhadak_hindi.jpg">Browser doesn't support this video format!</video><br></br>

	<div style="margin-left: 110px; margin-right: 100px; margin-bottom: 50px" >
		<p style="font-family: Papyrus; color:#C9380D; font-size: 40px; font-weight: 700" align="center">DHADAK</p><br>

	<p style="font-family: Papyrus; font-size: 35px; font-weight: 700">Hindi</p><br>

	<p id="round" style="font-family:Impact;"> UA</p><br><br>

	<image src="calendar-icon.png" width=50px height=40px><font size=5><b> 20-Jul-2018</b></font></image> &emsp;&emsp;

	<image src="clock_icon.png" width=40px height=35px><font size=5> 2hrs 18mins</font></image> <br><br>

	<image src="ratings_heart.png" width=50px height=40px><font size=6>68%</font></image>
	<br></br>

	<p id="rcorners" style="font-family:Impact"> Drama</p> &emsp;
	<p id="rcorners" style="font-family:Impact"> Romance</p>&emsp;
	<p id="rcorners" style="font-family:Impact"> Comedy</p>

	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	<?php  if (!isset($_SESSION['username'])) : ?>
		<input type="button" value="BOOK YOUR TICKETS!" onclick="f1()" style="background-color:#2E86C1; font-size: 20px; padding: 10px" >
	<?php endif ?>
	<?php  if (isset($_SESSION['username'])) : ?>
		<a href="theaters4.php" class="book">BOOK YOUR TICKETS!</a>
	<?php endif ?>
	<br><br>


	<h2 style="color:#A93226"> Synopsis</h2><br>
	<blockquote id="synopsis" style="font-family:Segoe Script">Set in the picturesque city of Udaipur, Dhadak is the story of Madhukar, the 20-year-old son of a lakeside restaurant owner, and the 19-year-old daughter of Udaipur's renowned politician, Parthavi. Madhukar's infatuation for Parthavi was all one-sided until they come face-to-face at a village fair. From the moment they set eyes on each other, Madhukar and Parthavi feel something familiar, something pure. 

Despite the warnings from their respective families, they both fall in love. But as their love blossoms, so do their problems. Torn between society and their families, their fate becomes uncertain. Dhadak is a simple, passionate story about first love.</blockquote>

	<br></br>

	<div align="center">

	<h2 style="color:#A93226"> User Reviews</h2><br>

	<p style="color:#3498DB"><font size=4><b>Nitish</b></font></p><br>
	<font size=3><b>Dhadak</b></font><br>
	<blockquote><font size="2">worst film ever. karan johar is carrying nepotism flag bearer of Bollywood . rightly said by kangana . first classic film like sairat should not be remake . shouldn't waste money.</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>Rajiv</b></font></p><br>
	<font size=3><b>Star Kid</b></font><br>
	<blockquote><font size="2">Now in India, All Star kid is Actor, whether they have talent or not. God Saves Bollywood. You don't need to be talented to become star now a days.</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>Nawaab</b></font></p><br>
	<font size=3><b>Not Sairat</b></font><br>
	<blockquote><font size="2">Movie direction is not good. Acting was good but story presentation was bad. Neither felt love nor fear in whole movie. In short it is not Sairat. Watch sairat with subtitle instead.</blockquote>


	</div>

	</div>

	<script type="text/javascript">
		function f1()
		{
			alert("Please Sign Up to continue!");
		}
		
	</script>
</body>
</html>