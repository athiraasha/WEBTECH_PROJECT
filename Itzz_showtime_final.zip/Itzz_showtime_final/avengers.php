<?php 
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Avengers:Infinity Wars</title>
	<link rel="stylesheet" type="text/css" href="ticket_booking_button.css">
	<link rel="shortcut icon" href="clapboard.png">

<style type="text/css">
	
		a.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 10px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}

		video
		{
			text-align:center;
			margin:0 auto;
			display:block;
			
			object-fit: inherit;

			max-height: 400px;
    		min-width: 100%;
   			object-fit: fill;
		}

		#rcorners
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 2px solid #909497;
    		padding: 20px; 
    		width: 60px;
    		height: 10px; 
    		text-align:center;   
		}

		#round
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 4px solid #909497;
    		padding: 20px 20px 22px 20px; 
    		width: 6px;
    		height: 6px; 
		}

</style>

<style>
	
	*{
		margin: 0;
		padding:0;
		font-family: verdana;
	}
#main{
	width: 100%;
	height:15vh;
}
nav{
	z-index:1;
	width: 100%;
	height: 80px;
	background-color: #000;
	line-height: 80px;
	position: fixed;
	top: 0;
}
nav ul{
	float: right;
	margin-right: 30px;
}
nav ul li{
	list-style-type: none;
	display: inline-block;
	transition: 0.8s all;
}

nav ul li:hover{
	background-color: #f39d1a;
}
nav ul li a{
	text-decoration: none;
	color: #fff;
	padding: 30px

}

#synopsis
{
	font-size: 20px;
	font-weight: 700;
}

</style>
</head>
<body>
	<div id="main">
		<nav>
		<img src="itzz_showtime_final.jpg" width="100" height="80">
			<ul>
				
				<?php  if (isset($_SESSION['username'])) : ?>
					
					<li style="color: white;"><img src="login_icon.jpg" width="30" height="30">Hi,<?php echo $_SESSION['username']; ?></li>

    				<li><a href="home_1.php?logout='1'">Sign Out</a></li>
    			<?php endif ?>
    			<?php  if (!isset($_SESSION['username'])) : ?>
					<li><a href="reg_1.php">Sign Up</a></li>
				<?php endif ?>
				<li><a href="About Us.html">About Us</a></li>
				<li><a href="Contact Us.html">Contact Us</a></li>
			</ul>
		</nav>
	</div>

	

	<video align="center" src="avengers-infinity-war-trailer-2_h720p.mov" controls poster="avengers-infinity-war-english.png">Browser doesn't support this video format!</video><br></br>

	<div style="margin-left: 110px; margin-right: 100px; margin-bottom: 50px" >

		<p style="font-family: Papyrus; color:#C9380D; font-size: 40px; font-weight: 700" align="center">AVENGERS: INFINITY WAR</p><br>
	<p style="font-family: Papyrus; font-size: 35px; font-weight: 700">English</p><br>

	<p id="round" style="font-family:Impact;"> UA</p><br><br>

	<image src="calendar-icon.png" width=50px height=40px><font size=5><b> 27-Apr-2018</b></font></image> &emsp;&emsp;

	<image src="clock_icon.png" width=40px height=35px><font size=5> 2hrs 29mins</font></image> <br><br>

	<image src="ratings_heart.png" width=50px height=40px><font size=6>88%</font></image>
	<br></br>

	<p id="rcorners" style="font-family:Impact"> Action</p> &emsp;
	<p id="rcorners" style="font-family:Impact"> Adventure</p>&emsp;
	<p id="rcorners" style="font-family:Impact"> Fantasy</p>

	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	<?php  if (!isset($_SESSION['username'])) : ?>
		<input type="button" value="BOOK YOUR TICKETS!" onclick="f1()" style="background-color:#2E86C1; font-size: 20px; padding: 10px" >
	<?php endif ?>
	<?php  if (isset($_SESSION['username'])) : ?>
		<a href="theaters5.php" class="book">BOOK YOUR TICKETS!</a>
	<?php endif ?>
	<br><br>


	<h2 style="color:#A93226"> Synopsis</h2><br>
	<blockquote id="synopsis" style="font-family:Segoe Script"> As the Avengers and their allies have continued to protect the world from threats too large for any one hero to handle, a new danger has emerged from the cosmic shadows: Thanos. A despot of intergalactic infamy, his goal is to collect all six Infinity Stones, artifacts of unimaginable power, and use them to inflict his twisted will on all of reality. Everything the Avengers have fought for has led up to this moment - the fate of Earth and existence itself has never been more uncertain.</blockquote>

	<br></br>

	<div align="center">

	<h2 style="color:#A93226"> User Reviews</h2><br>

	<p style="color:#3498DB"><font size=4><b>BMS Reviewer</b></font></p><br>
	<font size=3><b>Verdict: The perfect culmination of all the Marvel Cinematic Universe movies.</b></font><br>
	<blockquote><font size="2">There was an idea to change the way we look at superhero movies and that idea has come to its pinnacle and how. The foundation of the Marvel  Cinematic Universe lays on those fans have grown up reading comic books or even catching those animated TV shows and it is made for those very fans. Anthony and Joe Russo along with Kevin Feige have accomplished what would have once been impossible. Yes, Avengers Infinity War lives upto the mega-hype and we are ready to tell you all about it; spoiler free, of course.</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>The Times Of India</b></font></p><br>
	<font size=3><b>A great watch for those who want to catch the superhero action</b></font><br>
	<blockquote><font size="2">Irrespective of your opinion on the superhero film genre, you cannot deny that ‘Avengers: Infinity War’ is an ambitious undertaking – the biggest of its kind, making it a significant event in film history. Marvel Studios took a decade to meticulously plan this mammoth showdown of all their fictional heroes together for the first time on screen. To say that the MCU has a lot riding on this would be a gross understatement, evident by their massive marketing campaign visible everywhere. But the billion-dollar question is – does it live up to the hype.
</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>The Guardian</b></font></p><br>
	<font size=3><b>colossal Marvel showdown revels in apocalyptic mayhem</b></font><br>
	<blockquote><font size="2">Avengers:Infinity War is a giant battle for which directors Anthony and Joe Russo have given us touches of JRR Tolkien’s Return of the King and JK Rowling’s Harry Potter and the Deathly Hallows. The film delivers the sugar-rush of spectacle and some very amusing one-liners.

</blockquote>


	</div>

	</div>
	<script type="text/javascript">
		function f1()
		{
			alert("Please Sign Up to continue!");
		}
		
	</script>
</body>
</html>