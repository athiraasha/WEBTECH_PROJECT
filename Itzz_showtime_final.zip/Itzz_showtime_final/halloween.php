<?php 
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Halloween-2018</title>
	<link rel="stylesheet" type="text/css" href="ticket_booking_button.css">
	<link rel="shortcut icon" href="clapboard.png">

<style type="text/css">

		a.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 10px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}
	
		video
		{
			text-align:center;
			margin:0 auto;
			display:block;
			
			object-fit: inherit;
			max-height: 400px;
    		min-width: 100%;
   			object-fit: fill;
		}

		#rcorners
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 2px solid #909497;
    		padding: 20px; 
    		width: 50px;
    		height: 10px; 
    		text-align:center;   
		}

</style>

<style>
	
	*{
		margin: 0;
		padding:0;
		font-family: verdana;
	}
#main{
	width: 100%;
	height:15vh;
}
nav{
	z-index:1;
	width: 100%;
	height: 80px;
	background-color: #000;
	line-height: 80px;
	position: fixed;
	top: 0;
}
nav ul{
	float: right;
	margin-right: 30px;
}
nav ul li{
	list-style-type: none;
	display: inline-block;
	transition: 0.8s all;
}

nav ul li:hover{
	background-color: #f39d1a;
}
nav ul li a{
	text-decoration: none;
	color: #fff;
	padding: 30px

}

#synopsis
{
	font-size: 20px;
	font-weight: 700;
}
#round
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 4px solid #909497;
    		padding: 20px 20px 22px 20px; 
    		width: 6px;
    		height: 6px; 

    		   
		}
</style>
</head>
<body>
	<div id="main">
		<nav>
		<img src="itzz_showtime_final.jpg" width="100" height="80">
			<ul>
				
				<?php  if (isset($_SESSION['username'])) : ?>
					
					<li style="color: white;"><img src="login_icon.jpg" width="30" height="30">Hi,<?php echo $_SESSION['username']; ?></li>

    				<li><a href="home_1.php?logout='1'">Sign Out</a></li>
    			<?php endif ?>
    			<?php  if (!isset($_SESSION['username'])) : ?>
					<li><a href="reg_1.php">Sign Up</a></li>
				<?php endif ?>
				<li><a href="About Us.html">About Us</a></li>
				<li><a href="Contact Us.html">Contact Us</a></li>
			</ul>
		</nav>
	</div>

	
	<video align="center" src="(HDvd9.co)_Halloween---Official-Trailer-HD.mp4" controls poster="Halloween-2018-english.jpg">Browser doesn't support this video format!</video><br></br>
	<div style="margin-left: 110px; margin-right: 100px; margin-bottom: 50px" >

	<p style="font-family: Papyrus; color:#C9380D; font-size: 40px; font-weight: 700" align="center">HALLOWEEN</p><br>
	<p style="font-family: Papyrus; font-size: 35px; font-weight: 700">English</p><br>
	<p id="round" style="font-family:Impact;"> A</p><br><br>
	<image src="calendar-icon.png" width=50px height=40px><font size=5> <b>19-Oct-2018</b></font></image> &emsp;&emsp;
	<image src="clock_icon.png" width=40px height=35px><font size=5> 1hrs 48mins</font></image> <br><br>

	<image src="ratings_heart.png" width=50px height=40px><font size=6>67%</font></image>
	<br></br>

	<p id="rcorners" style="font-family:Impact">Horror</p> &emsp;
	<p id="rcorners" style="font-family:Impact"> Suspense </p>&emsp;
	<p id="rcorners" style="font-family:Impact"> Thriller</p>
	

	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	<?php  if (!isset($_SESSION['username'])) : ?>
		<input type="button" value="BOOK YOUR TICKETS!" onclick="f1()" style="background-color:#2E86C1; font-size: 20px; padding: 10px" >
	<?php endif ?>
	<?php  if (isset($_SESSION['username'])) : ?>
		<a href="theaters5.php" class="book">BOOK YOUR TICKETS!</a>
	<?php endif ?>
	<br><br>


	<h2 style="color:#A93226"> Synopsis</h2><br>
	<blockquote id="synopsis" style="font-family:Segoe Script">Laurie Strode comes to her final confrontation with Michael Myers, the masked figure who has haunted her since she narrowly escaped his killing spree on Halloween night four decades ago.


</blockquote>

	<br></br>

	<div align="center">

	<h2 style="color:#A93226"> User Reviews</h2><br>
	<font size=3><b>No users have reviewed this movie yet!</b></font><br>

	</div>

	</div>

	<script type="text/javascript">
		function f1()
		{
			alert("Please Sign Up to continue!");
		}
		
	</script>
</body>
</html>