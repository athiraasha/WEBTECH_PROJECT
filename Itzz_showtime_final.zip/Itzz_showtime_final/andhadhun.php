<?php 
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Andhadhun</title>
	<link rel="stylesheet" type="text/css" href="ticket_booking_button.css">
	<link rel="shortcut icon" href="clapboard.png">

<style type="text/css">

		a.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 10px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}
	
		video
		{
			text-align:center;
			margin:0 auto;
			display:block;
			
			object-fit: inherit;

			max-height: 400px;
    		min-width: 100%;
   			object-fit: fill;
		}

		#rcorners
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 2px solid #909497;
    		padding: 20px; 
    		width: 60px;
    		height: 10px; 
    		text-align:center;   
		}

		#round
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 4px solid #909497;
    		padding: 20px 20px 22px 20px; 
    		width: 6px;
    		height: 6px;    
		}

</style>

<style>
	
	*{
		margin: 0;
		padding:0;
		font-family: verdana;
	}
#main{
	width: 100%;
	height:15vh;
}
nav{
	z-index:1;
	width: 100%;
	height: 80px;
	background-color: #000;
	line-height: 80px;
	position: fixed;
	top: 0;
}
nav ul{
	float: right;
	margin-right: 30px;
}
nav ul li{
	list-style-type: none;
	display: inline-block;
	transition: 0.8s all;
}

nav ul li:hover{
	background-color: #f39d1a;
}
nav ul li a{
	text-decoration: none;
	color: #fff;
	padding: 30px

}

#synopsis
{
	font-size: 20px;
	font-weight: 700;
}

</style>
</head>
<body>
	<div id="main">
		<nav>
		<img src="itzz_showtime_final.jpg" width="100" height="80">
			<ul>
				
				<?php  if (isset($_SESSION['username'])) : ?>
					
					<li style="color: white;"><img src="login_icon.jpg" width="30" height="30">Hi,<?php echo $_SESSION['username']; ?></li>

    				<li><a href="home_1.php?logout='1'">Sign Out</a></li>
    			<?php endif ?>
    			<?php  if (!isset($_SESSION['username'])) : ?>
					<li><a href="reg_1.php">Sign Up</a></li>
				<?php endif ?>
				<li><a href="About Us.html">About Us</a></li>
				<li><a href="Contact Us.html">Contact Us</a></li>
			</ul>
		</nav>
	</div>

	
	<video align="center" src="AndhaDhun Official Trailer 720p HD(VipVideo.In).mp4" controls poster="Andhadhun_hindi.jpg">Browser doesn't support this video format!</video><br></br>

	<div style="margin-left: 110px; margin-right: 100px; margin-bottom: 50px" >
		<p style="font-family: Papyrus; color:#C9380D; font-size: 40px; font-weight: 700" align="center">ANDHADHUN</p><br>

	<p style="font-family: Papyrus; font-size: 35px; font-weight: 700">Hindi</p><br>

	<p id="round" style="font-family:Impact;"> UA</p><br><br>

	<image src="calendar-icon.png" width=50px height=40px><font size=5><b> 5-Oct-2018</b></font></image> &emsp;&emsp;

	<image src="clock_icon.png" width=40px height=35px><font size=5> 2hrs 20mins</font></image> <br><br>

	<image src="ratings_heart.png" width=50px height=40px><font size=6>86%</font></image>
	<br></br>

	<p id="rcorners" style="font-family:Impact"> Crime</p> &emsp;
	<p id="rcorners" style="font-family:Impact"> Thriller</p>

	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	<?php  if (!isset($_SESSION['username'])) : ?>
		<input type="button" value="BOOK YOUR TICKETS!" onclick="f1()" style="background-color:#2E86C1; font-size: 20px; padding: 10px" >
	<?php endif ?>
	<?php  if (isset($_SESSION['username'])) : ?>
		<a href="theaters3.php" class="book">BOOK YOUR TICKETS!</a>
	<?php endif ?>
	<br><br>


	<h2 style="color:#A93226"> Synopsis</h2><br>
	<blockquote id="synopsis" style="font-family:Segoe Script">A series of mysterious events take place in the life of a blind pianist (Ayushmann Khurrana). Now, he must report a crime that he never actually witnessed.</blockquote>

	<br></br>

	<div align="center">

	<h2 style="color:#A93226"> User Reviews</h2><br>

	<p style="color:#3498DB"><font size=4><b>Akash</b></font></p><br>
	<font size=3><b>Dhaansu Picture</b></font><br>
	<blockquote><font size="2">Isko kehte hain picture..kya bawaal movie banayi hai Shriram Raghavan ne..mze baandh die.. Direction,screenplay,kahani,background score sb faad..hr time baandh k rkhti hai..thoda predictable thi..pr wo na ho to thriller kaisi..gaane bhi acche hain..last wala bht hi mast hai.. Ayushman ne isse behter kaam apne abhi tk k career me nhi kia..punjabi launde wali image break krdi hai..tabu ne gazab kia hai..manan vij,zakir hussain,radhika apte,murli aur tai k role walon ne bhi bht sahi nibhaya hai.. Kul milakar acche cinema ka anubhav lena chahte hain ye movie zaroor dekhein..firse shriram raghavan k lie taaliyaan..😁</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>Shubham</b></font></p><br>
	<font size=3><b>Best thriller of the year</b></font><br>
	<blockquote><font size="2">Unbelievable Unexpected Incredible Andhadhun is one of the best thrillers in recent times..Sriram raghavan once again proves that he is the master of this genre..Take a bow Ayushman khurrana,film after film he's showing what he is capable of.He has pulled off a role of a lifetime..Must watch</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>Anshul</b></font></p><br>
	<font size=3><b>Genius, Pure genius</b></font><br>
	<blockquote><font size="2">When a Film keeps you hooked and you don't know what is coming in the next scene, Its needed to be appreciated. Thank God, there are Filmmakers still trying to Make Good Cinema.</blockquote>


	</div>

	</div>

	<script type="text/javascript">
		function f1()
		{
			alert("Please Sign Up to continue!");
		}
		
	</script>
</body>
</html>