<?php 
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Black Panther</title>
	<link rel="stylesheet" type="text/css" href="ticket_booking_button.css">
	<link rel="shortcut icon" href="clapboard.png">

<style type="text/css">
	
		a.book
		{
			background-color:#2E86C1; 
			font-size: 20px; 
			padding: 10px;
  			text-align: center;

  			-webkit-appearance: button;
    		-moz-appearance: button;
    		appearance: button;
   		 	text-decoration: none;
    		color: initial;
		}

		video
		{
			text-align:center;
			margin:0 auto;
			display:block;
			
			object-fit: inherit;

			max-height: 400px;
    		min-width: 100%;
   			object-fit: fill;
		}

		#rcorners
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 2px solid #909497;
    		padding: 20px; 
    		width: 60px;
    		height: 10px; 
    		text-align:center;   
		}

		#round
		{
			display:inline-block;
    		border-radius: 30px;
    		border: 4px solid #909497;
    		padding: 20px 20px 22px 20px; 
    		width: 6px;
    		height: 6px; 
		}

</style>

<style>
	
	*{
		margin: 0;
		padding:0;
		font-family: verdana;
	}
#main{
	width: 100%;
	height:15vh;
}
nav{
	z-index:1;
	width: 100%;
	height: 80px;
	background-color: #000;
	line-height: 80px;
	position: fixed;
	top: 0;
}
nav ul{
	float: right;
	margin-right: 30px;
}
nav ul li{
	list-style-type: none;
	display: inline-block;
	transition: 0.8s all;
}

nav ul li:hover{
	background-color: #f39d1a;
}
nav ul li a{
	text-decoration: none;
	color: #fff;
	padding: 30px

}

#synopsis
{
	font-size: 20px;
	font-weight: 700;
}

</style>
</head>
<body>
	<div id="main">
		<nav>
		<img src="itzz_showtime_final.jpg" width="100" height="80">
			<ul>
				
				<?php  if (isset($_SESSION['username'])) : ?>
					
					<li style="color: white;"><img src="login_icon.jpg" width="30" height="30">Hi,<?php echo $_SESSION['username']; ?></li>

    				<li><a href="home_1.php?logout='1'">Sign Out</a></li>
    			<?php endif ?>
    			<?php  if (!isset($_SESSION['username'])) : ?>
					<li><a href="reg_1.php">Sign Up</a></li>
				<?php endif ?>
				<li><a href="About Us.html">About Us</a></li>
				<li><a href="Contact Us.html">Contact Us</a></li>
			</ul>
		</nav>
	</div>

	
	<video align="center" src="black-panther-spot-rise-usca_h720p.mov" controls poster="BlackPanther-english.jpg">Browser doesn't support this video format!</video><br></br>

	<div style="margin-left: 110px; margin-right: 100px; margin-bottom: 50px" >
		<p style="font-family: Papyrus; color:#C9380D; font-size: 40px; font-weight: 700" align="center">BLACK PANTHER</p><br>

	<p style="font-family: Papyrus; font-size: 35px; font-weight: 700">English</p><br>

	<p id="round" style="font-family:Impact;"> UA</p><br><br>


	<image src="calendar-icon.png" width=50px height=40px><font size=5><b> 16-Feb-2018</b></font></image> &emsp;&emsp;

	<image src="clock_icon.png" width=40px height=35px><font size=5> 2hrs 14mins</font></image> <br><br>


	<image src="ratings_heart.png" width=50px height=40px><font size=6>85%</font></image>
	<br></br>

	<p id="rcorners" style="font-family:Impact"> Action</p> &emsp;
	<p id="rcorners" style="font-family:Impact"> Adventure</p>&emsp;
	<p id="rcorners" style="font-family:Impact"> Fantasy</p>

	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
	<?php  if (!isset($_SESSION['username'])) : ?>
		<input type="button" value="BOOK YOUR TICKETS!" onclick="f1()" style="background-color:#2E86C1; font-size: 20px; padding: 10px" >
	<?php endif ?>
	<?php  if (isset($_SESSION['username'])) : ?>
		<a href="theaters2.php" class="book">BOOK YOUR TICKETS!</a>
	<?php endif ?>
	<br><br>


	<h2 style="color:#A93226"> Synopsis</h2><br>
	<blockquote id="synopsis" style="font-family:Segoe Script"> After the events of Captain America: Civil War, King T'Challa returns home to the reclusive, technologically advanced African nation of Wakanda to serve as his country's new leader. However, T'Challa soon finds that he is challenged for the throne from factions within his own country. 

When two foes conspire to destroy Wakanda, the hero known as Black Panther must team up with C.I.A. agent Everett K. Ross and members of the Dora Milaje, Wakandan special forces, to prevent Wakanda from being dragged into a world war.</blockquote>

	<br></br>

	<div align="center">

	<h2 style="color:#A93226"> User Reviews</h2><br>

	<p style="color:#3498DB"><font size=4><b>BMS Reviewer</b></font></p><br>
	<font size=3><b>Verdict: A perfect standalone movie, as the MCU expands.</b></font><br>
	<blockquote><font size="2">Whether you love or hate what Marvel and Disney have done to the current Hollywood scenario with their cinematic universe, there is no doubt that they are taking the criticisms seriously and appointing directors who would do the most justice to the movie, exactly how Taika Waititi was a savior for Thor: Ragnarok. Marvel is taking another step in the right direction with Ryan Coogler as the director of Black Panther. T'Challa (Chadwick Boseman) aka Black Panther is one of the very few characters in MCU who before getting their own movie worked with team Avengers. It is a challenge when they have already established themselves as a part of a universe and then creating an identity for themselves; a feat the movie has completed effortlessly.</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>Firstpost</b></font></p><br>
	<font size=3><b>Unique directorial voice, rousing social commentary makes this Marvel film a winner</b></font><br>
	<blockquote><font size="2">No doubt about it - Black Panther is fun: it’s got all the grand VFX razzmatazz of a Marvel movie, enjoyable characters, a giant scale fit for the big screen, but more importantly, a villain who is relatable and memorable. And it looks like Marvel has finally begun to let their films have the voice of the director because this is more a Ryan Coogler movie than a studio mandated product.

We were introduced to the titular hero back in Captain America: Civil War, and luckily this is a film that doesn’t squeeze in other Avengers to shepherd or help him out at any point (looking at you Spiderman: Homecoming). This is Black Panther’s film – almost a show reel for how bad*ss Chadwick Boseman is going to be in the Infinity War movies.</blockquote>

<br>

	<p style="color:#3498DB"><font size=4><b>The Indian Express</b></font></p><br>
	<font size=3><b>This Chadwick Boseman starrer is a near-perfect superhero film</b></font><br>
	<blockquote><font size="2">Black Panther starts right after the events of Captain America: Civil War. King T’Chaka (John Kani) is dead and it’s time for T’Challa (Chadwick Boseman) to take over the throne. After a short lesson on Wakandan history, which is quite essential for this film, we are taken to the country of Wakanda and it is nothing less than a visual delight. To the world, they are a struggling nation but in reality, their technology is something that could inspire Charlie Brooker for another season of Black Mirror. Wakanda is a strong nation but it’s also vulnerable. With umpteen amounts of vibranium that they hold, this is their biggest weapon which could very well blow up in their face as well.</blockquote>


	</div>

	</div>

	<script type="text/javascript">
		function f1()
		{
			alert("Please Sign Up to continue!");
		}
		
	</script>
</body>
</body>
</html>