<?php 
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Select your seats</title>
	<link rel="shortcut icon" href="clapboard.png">
	<link rel="stylesheet" type="text/css" href="payment.css">
	<style type="text/css">

	#main{
	width: 100%;
	height:3vh;
}
nav{
	z-index: 1;
	width: 100%;
	height: 65px;
	background-color: #000;
	line-height: 65px;
	position: fixed;
	top: 0;
	font-family: Calibri;
	font-size: 17px;
}
nav ul{
	list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
	float: right;
	margin-right: 30px;
}
nav ul li{

	display: inline-block;
	transition: 0.8s all;
}

nav ul li:hover{
	background-color: #f39d1a;
}
nav ul li a{
	
	text-decoration: none;
	color: #fff;
	padding: 30px 30px;

}
		
	.outer{
    width: 700px;
    height:680px;
    border: 5px solid black;
    padding: 25px;
    margin: auto;
    background-color: #FFFFFF;
    border-radius: 25px

}
	.inner
	{
		width:600px;
		height:1px;
		border:5px solid black;
		padding:25px;
		background-color: #000000;
		text-align: center;
		

	}
	</style>
</head>
<body>
<div id="main">
		<nav>
		<img src="itzz_showtime_final.jpg" width="65px" height="65px">
			<ul>
				
				<?php  if (isset($_SESSION['username'])) : ?>
					
					<li style="color: white;"><img src="login_icon.jpg" width="30" height="30">Hi,<?php echo $_SESSION['username']; ?></li>

    				<li><a href="home_1.php?logout='1'">Sign Out</a></li>
    			<?php endif ?>
    			<?php  if (!isset($_SESSION['username'])) : ?>
					<li><a href="reg_1.php">Sign Up</a></li>
				<?php endif ?>
				<li><a href="About Us.html">About Us</a></li>
				<li><a href="Contact Us.html">Contact Us</a></li>
			</ul>
		</nav>
	</div>
	

	<h1 align="center" style="font-family: Gabriola; font-size: 45px;color: Brown;">Please choose your seats!</h1> 
	<div align="center" style="background-color: green; width: 200px; height: 25px; margin-left: 1100px; color: white; padding: 5px;float: right;">Double click for selecting seat</div><br><br><br>
	<div align="center" style="background-color: white; width: 200px; height: 25px; margin-left: 1100px; color: black; padding: 8px; border: solid;float: right;">Single click for unselecting seat</div><br>
	<div class="outer" align="center" >
		<div class="inner" style="text-align:center; color:white">SCREEN THIS WAY</div><br><br>
			<div style="margin-left: 60px">
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img1"><b>1A</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img1">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline:none;border-width: 0px;padding: 0px;float: left">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img2"><b>2A</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img2">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img3"><b>3A</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img3" >
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img4"><b>4A</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img4">
				</button>
				
			</div>
			<div>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px" class="buttons" id="img5">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img5"><b>5A</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img5">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" class="buttons" id="img6">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img6"><b>6A</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img6" >
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" class="buttons" id="img7">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img7"><b>7A</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img7" >
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" class="buttons" id="img8">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img8"><b>8A</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img8" >
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" class="buttons" id="img9">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img9"><b>9A</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img9">
				</button>
			</div><br>

			<div style="margin-left: 60px">
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left" class="buttons" id="img10">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img10"><b>1B</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img10">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline:none;border-width: 0px;padding: 0px;float: left" class="buttons" id="img11">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img11"><b>2B</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img11">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left" class="buttons" id="img12">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img12"><b>3B</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img12">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left" class="buttons" id="img13">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img13"><b>4B</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img13">
				</button>
				
			</div>
			<div>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px" class="buttons" id="img14">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img14"><b>5B</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img14" >
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" class="buttons" id="img15">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img15"><b>6B</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img15">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" class="buttons" id="img16">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img16"><b>7B</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img16">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" class="buttons" id="img17">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img17"><b>8B</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img17" >
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" class="buttons" id="img18">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img18"><b>9B</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img18" >
				</button>
			</div><br>

			<div style="margin-left: 60px">
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left" class="buttons" id="img19">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img19"><b>1C</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img19">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline:none;border-width: 0px;padding: 0px;float: left" class="buttons" id="img20">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img20"><b>2C</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img20">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left" class="buttons" id="img21">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img21"><b>3C</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img21">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left" class="buttons" id="img22">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img22"><b>4C</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img22">
				</button>
				
			</div>
			<div>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px" class="button" id="img23">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img23"><b>5C</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img23" >
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" class="buttons" id="img24">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img24"><b>6C</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img24">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" class="buttons" id="img25">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img25"><b>7C</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img25" >
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" class="buttons" id="img26">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img26"><b>8C</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img26">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" class="buttons" id="img27">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img27"><b>9C</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img27">
				</button>
			</div><br>


			<div style="margin-left: 60px">
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left" class="buttons" id="img28">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img28"><b>1D</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img28">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline:none;border-width: 0px;padding: 0px;float: left">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img29"><b>2D</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img29">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left" >
				<p id="seat" style="font-size: 16px;margin:-1px" id="img30"><b>3D</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img30">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left" class="buttons" id="img31">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img31"><b>4D</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img31">
				</button>
				
			</div>
			<div>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px" class="buttons" id="img32">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img32"><b>5D</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img32">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" class="buttons" id="img33">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img33"><b>6D</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img33">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img34"><b>7D</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img33">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img34"><b>8D</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img34">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img35"><b>9D</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img35" >
				</button>
			</div><br>

			<div style="margin-left: 60px">
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img36"><b>1E</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img36">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline:none;border-width: 0px;padding: 0px;float: left">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img37"><b>2E</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img37">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left" >
				<p id="seat" style="font-size: 16px;margin:-1px" id="img38"><b>3E</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img38" >
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;float: left" >
				<p id="seat" style="font-size: 16px;margin:-1px" id="img39"><b>4E</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img39" >
				</button>
				
			</div>
			<div>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px" >
				<p id="seat" style="font-size: 16px;margin:-1px" id="img40"><b>5E</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img40" >
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img41"><b>6E</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img41">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" >
				<p id="seat" style="font-size: 16px;margin:-1px" id="img42"><b>7E</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img42" >
				</button>
				<button type="button" style="background-color: transparent;border:none;outline: none;border-width: 0px;padding: 0px;" >
				<p id="seat" style="font-size: 16px;margin:-1px" id="img43"><b>8E</b></p>
				<img src="cross.png" width="60" height="60" style="margin:-2px" id="img43">
				</button>
				<button type="button" style="background-color: transparent;border:none;outline:none;border-width: 0px;padding: 0px;" class="buttons" id="img44">
				<p id="seat" style="font-size: 16px;margin:-1px" id="img44"s><b>9E</b></p>
				<img src="chair_image1.jpg" width="60" height="60" style="margin:-2px" id="img44">
				</button>
			</div><br>
				<img src="cash.png" width="50" height="50">
			<input type="button" value="total amount to be paid VIEW HERE!" style="background-color: transparent;border:none;outline:none;border-width: 0px;padding: 0px;font-size: 30px;font-family: Monotype Corsiva;color: blue" onclick="f1()"><br><br>
			
				<a  class="payment" onclick="f2()">PROCEED TO PAYMENT</a>

	</div>
	<script type="text/javascript">
		var items = document.querySelectorAll(".buttons");
		for (var i = 0; i < items.length; i++) 
		{
			var el = items[i];
			el.addEventListener("dblclick", doSomething);
			el.addEventListener("click", doSomething1);

		}
		var count=0;
		function doSomething(e)
		{
			count=count+750;
			var i=e.currentTarget.id;
			var ele=document.getElementById(i);
			ele.style.backgroundColor="green";
			ele.style.border="solid";
		}
		function doSomething1(e)
		{
			count=count-250;
			var i=e.currentTarget.id;
			var ele=document.getElementById(i);
			ele.style.backgroundColor="transparent";
			ele.style.border="none";
		}
		function f1()
		{
				if(count==0)
					alert("Please select your seats!");
				else
					alert("total amount is "+count);
		}

		function f2()
		{
				if(count==0)
					alert("Please select your seats!");
				else
					window.location.href="payment_page.html";
		}


		
	</script>
	

</body>
</html>
		