<?php include('server.php') ?>

<!DOCTYPE html>
<html>
<head>
	<title>Sign Up</title>
	<link rel="shortcut icon" href="clapboard.png">

<style>
	.box1
	{
		box-sizing:border-box;
		width: 40%;
    	border: 2px solid black;
		
    	
	}

	h2
	{
		font-family: "Ink Free";
		font-size:30px;
		font-style:oblique;
	
		
	}
	
	body 
	{ 
  		background: url(cinema_photo.jpg) no-repeat center center fixed; 
  		-webkit-background-size: cover;
  		-moz-background-size: cover;
  		-o-background-size: cover;
  		background-size: cover;
		
	}


</style>

</head>

<body>
	<!--<h1 align="center" style="font-family:Segoe Print"><font size="15" color="#CB4335"><i>Itzz Showtime</i></font></h2>
	<h2 align="center">Meet your next favourite MOVIE!!</h2>-->
	<img src="itzz_showtime_final.jpg" height="65px" width="65px"/>
	<form action="reg_1.php" method="POST">
		<?php include('errors.php'); ?>
		<p align="center" style="font-family:Monotype Corsiva; margin-top:2px"><font size="6">New here? Create your account NOW!!</font></p>

	<div align="center">	
		<div class="box1" align="center">	
			
		<h3 align="center" style="font-family: Book Antiqua">Sign Up with Email</h3>
			<label>Name<br><input type="text" name="name" required autofocus placeholder="Name"></label><br></br>
			<label>Username<br><input type="text" name="username"></label><br></br>
			<label>Email Address<br><input type="email" name="email" required placeholder="you@yours.com"></label><br></br>
			<label>Password<br><input type="password" name="password_1" required></label><br></br>


			
			<button type="submit" class="btn" name="reg_user">Register</button>    <p>Already a member? <a href="login_1.php"> Sign In</a>
		</div>
	</div>	
			
		
	