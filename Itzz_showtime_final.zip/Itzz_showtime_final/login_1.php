<?php include('server.php') ?>

<!DOCTYPE html>
<html>
<head>
	<title>Sign In</title>
	<link rel="shortcut icon" href="clapboard.png">
<style>
	.box1
	{
		box-sizing:border-box;
		width: 40%;
    	border: 2px solid black;
		
	}

	h2
	{
		font-family: "Ink Free";
		font-size:30px;
		font-style:oblique;
	
		
	}
	
	body 
	{ 
  		background: url(cinema_photo.jpg) no-repeat center center fixed; 
  		-webkit-background-size: cover;
  		-moz-background-size: cover;
  		-o-background-size: cover;
  		background-size: cover;
		opacity:0.9;
	}


</style>

</head>
<body>

	<img src="itzz_showtime_final.jpg" height="65px" width="65px"/>
	<form action="login_1.php" method="POST">
		<?php include('errors.php'); ?>
		
		<p align="center" style="font-family:Monotype Corsiva; margin-top:2px"><font size="6">Already a member? Sign in here</font></p>
		
	<div style="margin-top:30px" align="center">
		<div class="box1" align="center">
			<br>
			<label>Username<br><input type="text" name="username" autofocus required></label><br></br>
			<label>Password<br><input type="password" name="password" required></label><br></br>
			
			<input type="checkbox" name="Service" checked><font color="gray">Keep me signed in</font><br></br>

			<button type="submit" class="btn" name="login_user">Login</button> 
			<a href="Itzz_showtime_password.html">Forgot password</a>
			<br><br>
		</div>	

			
	

	</div>
			<p align="center"><br>Not a member?<a href="reg_1.php"> Sign Up</a></p>
			

</body>